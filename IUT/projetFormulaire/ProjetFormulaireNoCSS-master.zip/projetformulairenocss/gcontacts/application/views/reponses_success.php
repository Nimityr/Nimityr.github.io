<?php 
echo "<h2>$question</h2>";