<div class="alert-box -success">
	contact supprimé avec succès !
</div>
