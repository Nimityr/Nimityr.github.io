<div class="alert-box -success">
	<?=$nom?> <?=$prenom?> ajouté avec succès !
</div>
